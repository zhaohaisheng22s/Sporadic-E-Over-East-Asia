clc;
clear all;
close all

load('xamm.mat');load('xxmm.mat');load('wlmqmm.mat');load('szmm.mat');load('qdmm.mat');
load('mzlmm.mat');load('lzmm.mat');load('lsmm.mat');load('kmmm.mat');load('hkmm.mat');
load('gzmm.mat');load('bjmm.mat');load('ccmm.mat');load('cqmm.mat');load('okimm.mat');
load('kokmm.mat');load('akimm.mat');load('yammm.mat');load('wakmm.mat');load('ssmm.mat');
load('whmm.mat');
%%%%%%%%%%%%%%%%%%%%%�ձ仯
%%%%30��N
% subplot(1,2,1)
% plot(nanmean(lsmm));hold on; plot(nanmean(cqmm));hold on; plot(nanmean(whmm));hold on; 
% plot(nanmean(szmm));hold on; plot(nanmean(yammm));
% ylabel('Foes/MHz')
% xlabel('Time/Hour')
% set(gca,'xTick',1:2:24)
% set(gca,'XTickLabel',{'0','2','4','6','8','10','12','14','16','18','20','22'})
% %%%%120��E
% subplot(1,2,2)
% plot(nanmean(mzlmm));hold on; plot(nanmean(ccmm));hold on; plot(nanmean(qdmm));hold on; 
% plot(nanmean(szmm));hold on; plot(nanmean(gzmm));hold on; plot(nanmean(hkmm));
% ylabel('Foes/MHz')
% xlabel('Time/Hour')
% set(gca,'xTick',1:2:24)
% set(gca,'XTickLabel',{'0','2','4','6','8','10','12','14','16','18','20','22'})
%%%%%%%
%%%%%%%
%%%%%%%%%%%%%%%%%%%%%���ڱ仯
%%%%30��N
% figure
% for i=1:12
%     ls(i,:)=nanmean(lsmm(i:12:length(lsmm),:));
%     cq(i,:)=nanmean(cqmm(i:12:length(cqmm),:));
%     wh(i,:)=nanmean(whmm(i:12:length(whmm),:));
%     yam(i,:)=nanmean(yammm(i:12:length(yammm),:));
%     sz(i,:)=nanmean(szmm(i:12:length(szmm),:));
% end
% subplot(1,2,1)
% plot(nanmean(ls'));hold on; plot(nanmean(cq'));hold on; plot(nanmean(wh'));hold on; 
% plot(nanmean(sz'));hold on; plot(nanmean(yam'));
% ylabel('Foes/MHz')
% xlabel('Season/Month')
% % set(gca,'xTick',1:2:24)
% % set(gca,'XTickLabel',{'0','2','4','6','8','10','12','14','16','18','20','22'})
% %%%%120��E
% for i=1:12
% 
%     mz(i,:)=nanmean(mzlmm(i:12:length(mzlmm),:));
%     cc(i,:)=nanmean(ccmm(i:12:length(ccmm),:));
%     qd(i,:)=nanmean(qdmm(i:12:length(qdmm),:));
%     gz(i,:)=nanmean(gzmm(i:12:length(gzmm),:));
%     hk(i,:)=nanmean(hkmm(i:12:length(hkmm),:));
%     sz(i,:)=nanmean(szmm(i:12:length(szmm),:));
% end
% subplot(1,2,2)
% plot(nanmean(mz'));hold on; plot(nanmean(cc'));hold on; plot(nanmean(qd'));hold on; 
% plot(nanmean(sz'));hold on; plot(nanmean(gz'));hold on; plot(nanmean(hk'));
% ylabel('Foes/MHz')
% xlabel('Season/Month')
% % set(gca,'xTick',1:2:24)
% % set(gca,'XTickLabel',{'0','2','4','6','8','10','12','14','16','18','20','22'})
% %%%%%%%
% %%%%%%%

%%%%%%%%%%%%%%%%%%%%%�ձ仯+�±仯
for i=1:12
    wl(i,:)=nanmean(wlmqmm(i:12:length(wlmqmm),:));
    bj(i,:)=nanmean(bjmm(i:12:length(bjmm),:));
    mz(i,:)=nanmean(mzlmm(i:12:length(mzlmm),:));
    cc(i,:)=nanmean(ccmm(i:12:length(ccmm),:));
    wak(i,:)=nanmean(wakmm(i:12:length(wakmm),:));
    lz(i,:)=nanmean(lzmm(i:12:length(lzmm),:));
    xx(i,:)=nanmean(xxmm(i:12:length(xxmm),:));
    qd(i,:)=nanmean(qdmm(i:12:length(qdmm),:));
    aki(i,:)=nanmean(akimm(i:12:length(akimm),:));
    kok(i,:)=nanmean(kokmm(i:12:length(kokmm),:));
    ls(i,:)=nanmean(lsmm(i:12:length(lsmm),:));
    cq(i,:)=nanmean(cqmm(i:12:length(cqmm),:));
    wh(i,:)=nanmean(whmm(i:12:length(whmm),:));
    ss(i,:)=nanmean(ssmm(i:12:length(ssmm),:));
    yam(i,:)=nanmean(yammm(i:12:length(yammm),:));
    km(i,:)=nanmean(kmmm(i:12:length(kmmm),:));
    gz(i,:)=nanmean(gzmm(i:12:length(gzmm),:));
    hk(i,:)=nanmean(hkmm(i:12:length(hkmm),:));
    sz(i,:)=nanmean(szmm(i:12:length(szmm),:));
    oki(i,:)=nanmean(okimm(i:12:length(okimm),:));
    xa(i,:)=nanmean(xamm(i:12:length(xamm),:));
end
% subplot(4,5,1)
% wl(12,24)=10;
% imagesc(wl')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Urumchi')
% set(gca,'ydir','normal')
% 
% subplot(4,5,2)
% bj(12,24)=10;
% imagesc(bj')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Beijing')
% set(gca,'ydir','normal')
% 
% subplot(4,5,3)
% mz(12,24)=10;
% imagesc(mz')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Manzhouli')
% set(gca,'ydir','normal')
% 
% subplot(4,5,4)
% cc(12,24)=10;
% imagesc(cc')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Changchun')
% set(gca,'ydir','normal')
% 
% subplot(4,5,5)
% wak(12,24)=10;
% imagesc(wak')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Wakkanai')
% set(gca,'ydir','normal')
% 
% subplot(4,5,6)
% lz(12,24)=10;
% imagesc(lz')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Lanzhou')
% set(gca,'ydir','normal')
% ylabel('Time/hour')
% 
% subplot(4,5,7)
% xx(12,24)=10;
% imagesc(xx')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Xinxiang')
% set(gca,'ydir','normal')
% 
% subplot(4,5,8)
% qd(12,24)=10;
% imagesc(qd')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Qingdao')
% set(gca,'ydir','normal')
% 
% subplot(4,5,9)
% aki(12,24)=10;
% imagesc(aki')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Akita')
% set(gca,'ydir','normal')
% 
% subplot(4,5,10)
% kok(12,24)=10;
% imagesc(kok')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Koku')
% set(gca,'ydir','normal')
% colorbar;
% 
% subplot(4,5,11)
% ls(12,24)=10;
% imagesc(ls')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Lhasa')
% set(gca,'ydir','normal')
% 
% subplot(4,5,12)
% cq(12,24)=10;
% imagesc(cq')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Chongqing')
% set(gca,'ydir','normal')
% 
% subplot(4,5,13)
% wh(12,24)=10;
% imagesc(wh')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Wuhan')
% set(gca,'ydir','normal')
% 
% subplot(4,5,14)
% sz(12,24)=10;
% imagesc(sz')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Suzhou')
% set(gca,'ydir','normal')
% 
% subplot(4,5,15)
% yam(12,24)=10;
% imagesc(yam')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Yamagawa')
% set(gca,'ydir','normal')
% 
% subplot(4,5,16)
% km(12,24)=10;
% imagesc(km')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Kunming')
% set(gca,'ydir','normal')
% 
% subplot(4,5,17)
% gz(12,24)=10;
% imagesc(gz')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Guangzhou')
% set(gca,'ydir','normal')
% 
% 
% subplot(4,5,18)
% hk(12,24)=10;
% imagesc(hk')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Haikou')
% set(gca,'ydir','normal')
% xlabel('Season/month')
% 
% subplot(4,5,19)
% ss(12,24)=10;
% imagesc(ss')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Sheshan')
% set(gca,'ydir','normal')
% 
% subplot(4,5,20)
% oki(12,24)=10;
% imagesc(oki')
% set(gca,'YTick',1:4:24)
% set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% set(gca,'XTick',1:2:12)
% set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% %  axis([0 132 0 24]);
% title('Okinawa')
% set(gca,'ydir','normal')
%%%%%%%%
 
%  %%%%%%%%%%%%%%%%%%%%%���ڱ仯����ʱ��ң��󼾽ڱ仯ʱ��������
% bjs=nanmean(nanmean(bj(5:7,:)));
% ccs=nanmean(nanmean(cc(5:7,:)));
% cqs=nanmean(nanmean(cq(5:7,:)));
% hks=nanmean(nanmean(hk(5:7,:)));
% wls=nanmean(nanmean(wl(5:7,:)));
% lss=nanmean(nanmean(ls(5:7,:)));
% lzs=nanmean(nanmean(lz(5:7,:)));
% sss=nanmean(nanmean(ss(5:7,:)));
% xxs=nanmean(nanmean(xx(5:7,:)));
% mzs=nanmean(nanmean(mz(5:7,:)));
% szs=nanmean(nanmean(sz(5:7,:)));
% whs=nanmean(nanmean(wh(5:7,:)));
% qds=nanmean(nanmean(qd(5:7,:)));
% gzs=nanmean(nanmean(gz(5:7,:)));
% kms=nanmean(nanmean(km(5:7,:)));
% waks=nanmean(nanmean(wak(5:7,:)));
% yams=nanmean(nanmean(yam(5:7,:)));
% akis=nanmean(nanmean(aki(5:7,:)));
% koks=nanmean(nanmean(kok(5:7,:)));
% okis=nanmean(nanmean(oki(5:7,:)));
% xas=nanmean(nanmean(xa(5:7,:)));
% 
% 
% 
% bjw(1,:)=bj(1,:);
% bjw(2:3,:)=bj(11:12,:);
% bjw=nanmean(nanmean(bjw));
% 
% ccw(1,:)=cc(1,:);
% ccw(2:3,:)=cc(11:12,:);
% ccw=nanmean(nanmean(ccw));
% 
% cqw(1,:)=cq(1,:);
% cqw(2:3,:)=cq(11:12,:);
% cqw=nanmean(nanmean(cqw));
% 
% hkw(1,:)=hk(1,:);
% hkw(2:3,:)=hk(11:12,:);
% hkw=nanmean(nanmean(hkw));
% 
% wlw(1,:)=wl(1,:);
% wlw(2:3,:)=wl(11:12,:);
% wlw=nanmean(nanmean(wlw));
% 
% lsw(1,:)=ls(1,:);
% lsw(2:3,:)=ls(11:12,:);
% lsw=nanmean(nanmean(lsw));
% 
% lzw(1,:)=lz(1,:);
% lzw(2:3,:)=lz(11:12,:);
% lzw=nanmean(nanmean(lzw));
% 
% ssw(1,:)=ss(1,:);
% ssw(2:3,:)=ss(11:12,:);
% ssw=nanmean(nanmean(ssw));
% 
% mzw(1,:)=mz(1,:);
% mzw(2:3,:)=mz(11:12,:);
% mzw=nanmean(nanmean(mzw));
% 
% szw(1,:)=sz(1,:);
% szw(2:3,:)=sz(11:12,:);
% szw=nanmean(nanmean(szw));
% 
% whw(1,:)=wh(1,:);
% whw(2:3,:)=wh(11:12,:);
% whw=nanmean(nanmean(whw));
% 
% qdw(1,:)=qd(1,:);
% qdw(2:3,:)=qd(11:12,:);
% qdw=nanmean(nanmean(qdw));
% 
% gzw(1,:)=gz(1,:);
% gzw(2:3,:)=gz(11:12,:);
% gzw=nanmean(nanmean(gzw));
% 
% xxw(1,:)=xx(1,:);
% xxw(2:3,:)=xx(11:12,:);
% xxw=nanmean(nanmean(xxw));
% 
% kmw(1,:)=km(1,:);
% kmw(2:3,:)=km(11:12,:);
% kmw=nanmean(nanmean(kmw));
% 
% wakw(1,:)=wak(1,:);
% wakw(2:3,:)=wak(11:12,:);
% wakw=nanmean(nanmean(wakw));
% 
% yamw(1,:)=yam(1,:);
% yamw(2:3,:)=yam(11:12,:);
% yamw=nanmean(nanmean(yamw));
% 
% akiw(1,:)=aki(1,:);
% akiw(2:3,:)=aki(11:12,:);
% akiw=nanmean(nanmean(akiw));
% 
% kokw(1,:)=kok(1,:);
% kokw(2:3,:)=kok(11:12,:);
% kokw=nanmean(nanmean(kokw));
% 
% okiw(1,:)=oki(1,:);
% okiw(2:3,:)=oki(11:12,:);
% okiw=nanmean(nanmean(okiw));
% 
% xaw(1,:)=xa(1,:);
% xaw(2:3,:)=xa(11:12,:);
% xaw=nanmean(nanmean(xaw));
% 
% lonB=70:.5:150;
% latB=15:.5:55;
% 
% % load('zsummer.mat')
% % Zday=zsummer;
% % Zday=[28.42  47.49  39.36  48.9  48.68  59.48  56.48  71.24  71.08  59.4 67.83  53.4  59.37  66.24 60.791  64.15 59.43]/100;
% % Zday=[8.53 14.29 19.26 15.22 19.98 23.80 20.72 24.55 36.14 20.5 17.21 8.35 20.833 37.06 32.095 36.10  23.96]/100;
% latA=[49.58  43.84  43.75  40.11  36.24  36.06  31     29.63 29.5  25.5  23.15   20    30.5  31.2  26.3  39.7  45.4 35.26  31.3  35.7 34.23];
% lonA=[117.45 125.27 87.63 116.27 120.41 103.87 121.24 91.28 106.4 103.8 113.35 110.33 114.4 130.6 127.8 140.1 141.7 113.9  120.6 139.5 108.92];
% Zday=[mzs ccs wls bjs qds lzs sss lss cqs kms gzs hks whs yams okis akis waks  xxs szs koks xas]; 
% Zw=[mzw ccw wlw bjw qdw lzw ssw lsw cqw kmw gzw hkw whw yamw okiw akiw wakw  xxw szw kokw xaw]; 
% Z=zeros(81,161);
% for i=1:81
%     for j=1:161
%         count=0;
%         for ii=1:21
%             d(ii)=((lonA(ii)-lonB(j))^2+25*(latA(ii)-latB(i))^2)^1/2;
%             Z(i,j)=Z(i,j)+1/d(ii)*Zday(ii);
%             count=count+1/d(ii);
%         end
%         Z(i,j)=Z(i,j)/count;
%     end
% end
% Z1=Z;
% Z=zeros(81,161);
% for i=1:81
%     for j=1:161
%         count=0;
%         for ii=1:21
%             d(ii)=((lonA(ii)-lonB(j))^2+25*(latA(ii)-latB(i))^2)^1/2;
%             Z(i,j)=Z(i,j)+1/d(ii)*Zw(ii);
%             count=count+1/d(ii);
%         end
%         Z(i,j)=Z(i,j)/count;
%     end
% end
% Z2=Z;
% % v=0.2:.05:.7;
% % contourf(70:140,15:55,Z,v);
% %  Z1=Z;
% figure
% subplot(2,1,1), 
% imagesc(70:.5:150,15:.5:55,Z1)
% colorbar;
% set(gca,'ydir','normal')
% grid;
% ylabel('Latitude(deg.)'); xlabel('Longitude(deg.)');
% hold on
% map
% % plot_map;
% 
% subplot(2,1,2), 
% imagesc(70:.5:150,15:.5:55,Z2)
% colorbar;
% grid;
% set(gca,'ydir','normal')
% ylabel('Latitude(deg.)'); xlabel('Longitude(deg.)');
% hold on
% map
% % plot_map;
% % save('Z1.mat','Z1');
% 
% % clear bjw; clear bjs
%  %%%%%%%%%%%%%%%%%%%%%���ڱ仯����ʱ��ң��󼾽ڱ仯ʱ�������ã���ֹ����
% 
% %%%%%%%%%%%%%%%%%%%%%��ҹ�仯��ͼ
% bjs=nanmean(nanmean(bj(:,9:15)));
% ccs=nanmean(nanmean(cc(:,9:15)));
% cqs=nanmean(nanmean(cq(:,9:15)));
% hks=nanmean(nanmean(hk(:,9:15)));
% wls=nanmean(nanmean(wl(:,9:15)));
% lss=nanmean(nanmean(ls(:,9:15)));
% lzs=nanmean(nanmean(lz(:,9:15)));
% sss=nanmean(nanmean(ss(:,9:15)));
% xxs=nanmean(nanmean(xx(:,9:15)));
% mzs=nanmean(nanmean(mz(:,9:15)));
% szs=nanmean(nanmean(sz(:,9:15)));
% whs=nanmean(nanmean(wh(:,9:15)));
% qds=nanmean(nanmean(qd(:,9:15)));
% gzs=nanmean(nanmean(gz(:,9:15)));
% kms=nanmean(nanmean(km(:,9:15)));
% waks=nanmean(nanmean(wak(:,9:15)));
% yams=nanmean(nanmean(yam(:,9:15)));
% akis=nanmean(nanmean(aki(:,9:15)));
% koks=nanmean(nanmean(kok(:,9:15)));
% okis=nanmean(nanmean(oki(:,9:15)));
% xas=nanmean(nanmean(xa(:,9:15)));
% bjw(:,1:5)=bj(:,1:5);
% bjw(:,6)=bj(:,24);
% bjw=nanmean(nanmean(bjw));
% 
% ccw(:,1:5)=cc(:,1:5);
% ccw(:,6)=cc(:,24);
% ccw=nanmean(nanmean(ccw));
% 
% cqw(:,1:5)=cq(:,1:5);
% cqw(:,6)=cq(:,24);
% cqw=nanmean(nanmean(cqw));
% 
% hkw(:,1:5)=hk(:,1:5);
% hkw(:,6)=hk(:,24);
% hkw=nanmean(nanmean(hkw));
% 
% wlw(:,1:5)=wl(:,1:5);
% wlw(:,6)=wl(:,24);
% wlw=nanmean(nanmean(wlw));
% 
% lsw(:,1:5)=ls(:,1:5);
% lsw(:,6)=ls(:,24);
% lsw=nanmean(nanmean(lsw));
% 
% lzw(:,1:5)=lz(:,1:5);
% lzw(:,6)=lz(:,24);
% lzw=nanmean(nanmean(lzw));
% 
% ssw(:,1:5)=ss(:,1:5);
% ssw(:,6)=ss(:,24);
% ssw=nanmean(nanmean(ssw));
% 
% mzw(:,1:5)=mz(:,1:5);
% mzw(:,6)=mz(:,24);
% mzw=nanmean(nanmean(mzw));
% 
% szw(:,1:5)=sz(:,1:5);
% szw(:,6)=sz(:,24);
% szw=nanmean(nanmean(szw));
% 
% whw(:,1:5)=wh(:,1:5);
% whw(:,6)=wh(:,24);
% whw=nanmean(nanmean(whw));
% 
% qdw(:,1:5)=qd(:,1:5);
% qdw(:,6)=qd(:,24);
% qdw=nanmean(nanmean(qdw));
% 
% gzw(:,1:5)=gz(:,1:5);
% gzw(:,6)=gz(:,24);
% gzw=nanmean(nanmean(gzw));
% 
% xxw(:,1:5)=xx(:,1:5);
% xxw(:,6)=xx(:,24);
% xxw=nanmean(nanmean(xxw));
% 
% kmw(:,1:5)=km(:,1:5);
% kmw(:,6)=km(:,24);
% kmw=nanmean(nanmean(kmw));
% 
% wakw(:,1:5)=wak(:,1:5);
% wakw(:,6)=wak(:,24);
% wakw=nanmean(nanmean(wakw));
% 
% yamw(:,1:5)=yam(:,1:5);
% yamw(:,6)=yam(:,24);
% yamw=nanmean(nanmean(yamw));
% 
% akiw(:,1:5)=aki(:,1:5);
% akiw(:,6)=aki(:,24);
% akiw=nanmean(nanmean(akiw));
% 
% kokw(:,1:5)=kok(:,1:5);
% kokw(:,6)=kok(:,24);
% kokw=nanmean(nanmean(kokw));
% 
% okiw(:,1:5)=oki(:,1:5);
% okiw(:,6)=oki(:,24);
% okiw=nanmean(nanmean(okiw));
% 
% xaw(:,1:5)=xa(:,1:5);
% xaw(:,6)=xa(:,24);
% xaw=nanmean(nanmean(xaw));
% 
% lonB=70:.5:150;
% latB=15:.5:55;
% 
% % load('zsummer.mat')
% % Zday=zsummer;
% % Zday=[28.42  47.49  39.36  48.9  48.68  59.48  56.48  71.24  71.08  59.4 67.83  53.4  59.37  66.24 60.791  64.15 59.43]/100;
% % Zday=[8.53 14.29 19.26 15.22 19.98 23.80 20.72 24.55 36.14 20.5 17.21 8.35 20.833 37.06 32.095 36.10  23.96]/100;
% latA=[49.58  43.84  43.75  40.11  36.24  36.06  31     29.63 29.5  25.5  23.15   20    30.5  31.2  26.3  39.7  45.4 35.26  31.3  35.7 34.23];
% lonA=[117.45 125.27 87.63 116.27 120.41 103.87 121.24 91.28 106.4 103.8 113.35 110.33 114.4 130.6 127.8 140.1 141.7 113.9  120.6 139.5 108.92];
% Zday=[mzs ccs wls bjs qds lzs sss lss cqs kms gzs hks whs yams okis akis waks  xxs szs koks xas]; 
% Zw=[mzw ccw wlw bjw qdw lzw ssw lsw cqw kmw gzw hkw whw yamw okiw akiw wakw  xxw szw kokw xaw]; 
% Z=zeros(81,161);
% for i=1:81
%     for j=1:161
%         count=0;
%         for ii=1:21
%             d(ii)=((lonA(ii)-lonB(j))^2+25*(latA(ii)-latB(i))^2)^1/2;
%             Z(i,j)=Z(i,j)+1/d(ii)*Zday(ii);
%             count=count+1/d(ii);
%         end
%         Z(i,j)=Z(i,j)/count;
%     end
% end
% Z1=Z;
% Z=zeros(81,161);
% for i=1:81
%     for j=1:161
%         count=0;
%         for ii=1:21
%             d(ii)=((lonA(ii)-lonB(j))^2+25*(latA(ii)-latB(i))^2)^1/2;
%             Z(i,j)=Z(i,j)+1/d(ii)*Zw(ii);
%             count=count+1/d(ii);
%         end
%         Z(i,j)=Z(i,j)/count;
%     end
% end
% Z2=Z;
% % v=0.2:.05:.7;
% % contourf(70:140,15:55,Z,v);
% %  Z1=Z;
% figure
% subplot(2,1,1), 
% imagesc(70:.5:150,15:.5:55,Z1)
% colorbar;
% set(gca,'ydir','normal')
% % grid;
% ylabel('Latitude/deg.'); xlabel('Longitude/deg.');
% hold on
% map
% % plot_map;
% 
% subplot(2,1,2), 
% imagesc(70:.5:150,15:.5:55,Z2)
% colorbar;
% hold on
% map
% % grid;
% set(gca,'ydir','normal')
% ylabel('Latitude/deg.'); xlabel('Longitude/deg.');
% % % plot_map;
% % % save('Z1.mat','Z1');
% % % % 
% % 
%%%%%%%%%%%%%%%%%%%%%ȫ��ƽ���仯��ͼ
bjs=nanmean(nanmean(bj));
ccs=nanmean(nanmean(cc));
cqs=nanmean(nanmean(cq));
hks=nanmean(nanmean(hk));
wls=nanmean(nanmean(wl));
lss=nanmean(nanmean(ls));
lzs=nanmean(nanmean(lz));
sss=nanmean(nanmean(ss));
xxs=nanmean(nanmean(xx));
mzs=nanmean(nanmean(mz));
szs=nanmean(nanmean(sz));
whs=nanmean(nanmean(wh));
qds=nanmean(nanmean(qd));
gzs=nanmean(nanmean(gz));
kms=nanmean(nanmean(km));
waks=nanmean(nanmean(wak));
yams=nanmean(nanmean(yam));
akis=nanmean(nanmean(aki));
koks=nanmean(nanmean(kok));
okis=nanmean(nanmean(oki));
xas=nanmean(nanmean(xa));

lonB=70:.5:150;
latB=15:.5:55;

% load('zsummer.mat')
% Zday=zsummer;
% Zday=[28.42  47.49  39.36  48.9  48.68  59.48  56.48  71.24  71.08  59.4 67.83  53.4  59.37  66.24 60.791  64.15 59.43]/100;
% Zday=[8.53 14.29 19.26 15.22 19.98 23.80 20.72 24.55 36.14 20.5 17.21 8.35 20.833 37.06 32.095 36.10  23.96]/100;
latA=[49.58  43.84  43.75  40.11  36.24  36.06  31     29.63 29.5  25.5  23.15   20    30.5  31.2  26.3  39.7  45.4 35.26  31.3  35.7 34.23];
lonA=[117.45 125.27 87.63 116.27 120.41 103.87 121.24 91.28 106.4 103.8 113.35 110.33 114.4 130.6 127.8 140.1 141.7 113.9  120.6 139.5 108.92];
Zday=[mzs ccs wls bjs qds lzs sss lss cqs kms gzs hks whs yams okis akis waks  xxs szs koks xas]; 
Z=zeros(81,161);
for i=1:81
    for j=1:161
        count=0;
        for ii=1:21
            d(ii)=((lonA(ii)-lonB(j))^2+25*(latA(ii)-latB(i))^2)^1/2;
            Z(i,j)=Z(i,j)+1/d(ii)*Zday(ii);
            count=count+1/d(ii);
        end
        Z(i,j)=Z(i,j)/count;
    end
end
Z1=Z;
% Z=zeros(81,161);
% for i=1:81
%     for j=1:161
%         count=0;
%         for ii=1:21
%             d(ii)=((lonA(ii)-lonB(j))^2+25*(latA(ii)-latB(i))^2)^1/2;
%             Z(i,j)=Z(i,j)+1/d(ii)*Zw(ii);
%             count=count+1/d(ii);
%         end
%         Z(i,j)=Z(i,j)/count;
%     end
% end
% Z2=Z;
% v=0.2:.05:.7;
% contourf(70:140,15:55,Z,v);
%  Z1=Z;
figure
imagesc(70:.5:150,15:.5:55,Z1)
colorbar;
set(gca,'ydir','normal')
% grid;
ylabel('Latitude/deg.'); xlabel('Longitude/deg.');
hold on
map
% plot_map;
% % %%%%%%%%%%%%%%
% % 
% % %%%%%%%%%%%%%%%%%%%���ڱ仯
% % figure
% % mzlmm(756,1)=10;
% % subplot(6,1,1)
% % imagesc(mzlmm(481:756,:)');
% % set(gca,'YTick',1:4:24)
% % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',6:24:270)
% % set(gca,'XTickLabel',{'1998','2000','2002','2004','2006','2008','2010','2012','2014','2016','2018','2020'})
% % set(gca,'ydir','normal')
% % title('Manzhouli')
% % 
% % % subplot(8,1,2)
% % % wumqmm(756,1)=10;
% % % imagesc(wlmqmm(481:756,:)')
% % % % plot(nanmean(wlmqmm'));
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % % % set(gca,'XTick',1:2:12)
% % % % set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% % % set(gca,'ydir','normal')
% % 
% % % subplot(8,1,3)
% % % ccmm(768,1)=10;
% % % % plot(nanmean(ccmm'))
% % % imagesc(ccmm(493:768,:)')
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % % % set(gca,'XTick',1:2:12)
% % % % set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% % % set(gca,'ydir','normal')
% % 
% % subplot(6,1,2)
% % bjmm(756,1)=10;
% % % plot(nanmean(bjmm'))
% % imagesc(bjmm(481:756,:)')
% % set(gca,'YTick',1:4:24)
% % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',6:24:270)
% % set(gca,'XTickLabel',{'1998','2000','2002','2004','2006','2008','2010','2012','2014','2016','2018','2020'})
% % set(gca,'ydir','normal')
% % title('Beijing')
% % 
% % % subplot(5,1,3)
% % % lzmm(756,1)=10;
% % % % plot(nanmean(lzmm'))
% % % imagesc(lzmm(481:756,:)')
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % % % set(gca,'XTick',1:2:12)
% % % % set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% % % set(gca,'ydir','normal')
% % 
% % subplot(6,1,3)
% % cqmm(756,1)=10;
% % % plot(nanmean(cqmm'))
% % imagesc(cqmm(481:756,:)')
% % set(gca,'YTick',1:4:24)
% % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',6:24:270)
% % set(gca,'XTickLabel',{'1998','2000','2002','2004','2006','2008','2010','2012','2014','2016','2018','2020'})
% % set(gca,'ydir','normal')
% % title('Chongqing')
% % ylabel('Time/Hour'); 
% % 
% % subplot(6,1,4)
% % gzmm(756,1)=10;
% % % plot(nanmean(gzmm'))
% % imagesc(gzmm(481:756,:)')
% % set(gca,'YTick',1:4:24)
% % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',6:24:270)
% % set(gca,'XTickLabel',{'1998','2000','2002','2004','2006','2008','2010','2012','2014','2016','2018','2020'})
% % set(gca,'ydir','normal')
% % title('Guangzhou')
% % 
% % subplot(6,1,5)
% % hkmm(756,1)=10;
% % % plot(nanmean(hkmm'))
% % imagesc(hkmm(481:756,:)')
% % set(gca,'YTick',1:4:24)
% % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',6:24:270)
% % set(gca,'XTickLabel',{'1998','2000','2002','2004','2006','2008','2010','2012','2014','2016','2018','2020'})
% % set(gca,'ydir','normal')
% % title('Haikou')
% % 
% % subplot(6,1,6)
% % load('solar.mat')
% % % hkmm(756,1)=10;
% % % plot(nanmean(hkmm'))
% % % imagesc(hkmm(481:756,:)')
% % plot(solar)
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',6:24:270)
% % set(gca,'XTickLabel',{'1998','2000','2002','2004','2006','2008','2010','2012','2014','2016','2018','2020'})
% % set(gca,'ydir','normal')
% % title('Sunspot')
% % ylabel('Sunspot numbers'); xlabel('Year');
% % %%%%%%%%%%%%%%%���ڱ仯----�ս��----
% % 
% % 
% % %%%%%%%%%%%%%%%%%%%�����½����Ʒ���
% % figure
% % % mzlmm(756,1)=10;
% % subplot(3,2,1)
% % plot(nanmean(wlmqmm'));
% % temp=nanmean(wlmqmm');
% % % count=0;
% % % for i=1:756;
% % %     if ~isnan(temp(i))==1
% % %         count=count+1;
% % %         temp2(count)=temp(i);
% % %     end
% % % end
% % % x=1:count;
% % % a=polyfit(x,temp2,1);
% % temp3=nanmean(temp);
% % for i=1:length(temp)
% %     if ~isnan(temp(i))==1
% %         temp(i)=temp(i);
% %     else
% %         temp(i)=temp3;
% %     end
% % end
% % x=1:length(temp);
% % a=polyfit(x,temp,1);
% % y=a(1)*x+a(2);
% % hold on
% % plot(x,y,'r');
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',30:120:750)
% % set(gca,'XTickLabel',{'1960','1970','1980','1990','2000','2010','2020'})
% % set(gca,'ydir','normal')
% % title('Urumqi')
% % clear temp; clear temp2;
% % 
% % % subplot(8,1,2)
% % % wumqmm(756,1)=10;
% % % imagesc(wlmqmm(481:756,:)')
% % % % plot(nanmean(wlmqmm'));
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % % % set(gca,'XTick',1:2:12)
% % % % set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% % % set(gca,'ydir','normal')
% % 
% % % subplot(8,1,3)
% % % ccmm(768,1)=10;
% % % % plot(nanmean(ccmm'))
% % % imagesc(ccmm(493:768,:)')
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % % % set(gca,'XTick',1:2:12)
% % % % set(gca,'XTickLabel',{'1','3','5','7','9','11'})
% % % set(gca,'ydir','normal')
% % 
% % subplot(3,2,2)
% % % bjmm(756,1)=10;
% % % plot(nanmean(bjmm'))
% % plot(nanmean(bjmm'))
% % temp=nanmean(bjmm');
% % % count=0;
% % % for i=1:756;
% % %     if ~isnan(temp(i))==1
% % %         count=count+1;
% % %         temp2(count)=temp(i);
% % %     end
% % % end
% % % x=1:count;
% % % a=polyfit(x,temp2,1);
% % temp3=nanmean(temp);
% % for i=1:length(temp)
% %     if ~isnan(temp(i))==1
% %         temp(i)=temp(i);
% %     else
% %         temp(i)=temp3;
% %     end
% % end
% % x=1:length(temp);
% % a=polyfit(x,temp,1);
% % y=a(1)*x+a(2);
% % hold on
% % plot(x,y,'r');
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',30:120:750)
% % set(gca,'XTickLabel',{'1960','1970','1980','1990','2000','2010','2020'})
% % set(gca,'ydir','normal')
% % title('Beijing')
% % clear temp; clear temp2;
% % 
% % subplot(3,2,3)
% % % lzmm(756,1)=10;
% % plot(nanmean(lzmm'))
% % temp=nanmean(lzmm');
% % 
% % temp3=nanmean(temp);
% % for i=1:length(temp)
% %     if ~isnan(temp(i))==1
% %         temp(i)=temp(i);
% %     else
% %         temp(i)=temp3;
% %     end
% % end
% % x=1:length(temp);
% % a=polyfit(x,temp,1);
% % % count=0;
% % % for i=1:756;
% % %     if ~isnan(temp(i))==1
% % %         count=count+1;
% % %         temp2(count)=temp(i);
% % %     end
% % % end
% % % x=1:count;
% % % a=polyfit(x,temp2,1);
% % y=a(1)*x+a(2);
% % hold on
% % plot(x,y,'r');
% % % imagesc(lzmm(481:756,:)')
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',30:120:750)
% % set(gca,'XTickLabel',{'1960','1970','1980','1990','2000','2010','2020'})
% % set(gca,'ydir','normal')
% % ylabel('Foes/MHz')
% % title('Lanzhou')
% % clear temp; clear temp2;
% % 
% % subplot(3,2,4)
% % % cqmm(756,1)=10;
% % % plot(nanmean(cqmm'))
% % plot(nanmean(cqmm'))
% % temp=nanmean(cqmm');
% % % % count=0;
% % % % for i=1:756;
% % % %     if ~isnan(temp(i))==1
% % % %         count=count+1;
% % % %         temp2(count)=temp(i);
% % % %     end
% % % % end
% % % % x=1:count;
% % 
% % temp3=nanmean(temp);
% % for i=1:length(temp)
% %     if ~isnan(temp(i))==1
% %         temp(i)=temp(i);
% %     else
% %         temp(i)=temp3;
% %     end
% % end
% % x=1:length(temp);
% % a=polyfit(x,temp,1);
% % y=a(1)*x+a(2);
% % hold on
% % plot(x,y,'r');
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',30:120:750)
% % set(gca,'XTickLabel',{'1960','1970','1980','1990','2000','2010','2020'})
% % set(gca,'ydir','normal')
% % title('Chongqing')
% % clear temp; clear temp2;
% % % ylabel('Time/Hour'); 
% % 
% % subplot(3,2,5)
% % % gzmm(756,1)=10;
% % % plot(nanmean(gzmm'))
% % plot(nanmean(gzmm'))
% % temp=nanmean(gzmm');
% % % count=0;
% % % for i=1:756;
% % %     if ~isnan(temp(i))==1
% % %         count=count+1;
% % %         temp2(count)=temp(i);
% % %     end
% % % end
% % % x=1:count;
% % temp3=nanmean(temp);
% % for i=1:length(temp)
% %     if ~isnan(temp(i))==1
% %         temp(i)=temp(i);
% %     else
% %         temp(i)=temp3;
% %     end
% % end
% % x=1:length(temp);
% % a=polyfit(x,temp,1);
% % y=a(1)*x+a(2);
% % hold on
% % plot(x,y,'r');
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',30:120:750)
% % set(gca,'XTickLabel',{'1960','1970','1980','1990','2000','2010','2020'})
% % set(gca,'ydir','normal')
% % xlabel('year')
% % title('Guangzhou')
% % clear temp; clear temp2;
% % 
% % subplot(3,2,6)
% % % hkmm(756,1)=10;
% % % plot(nanmean(hkmm'))
% % plot(nanmean(hkmm'))
% % temp=nanmean(hkmm');
% % % % count=0;
% % % % for i=1:756;
% % % %     if ~isnan(temp(i))==1
% % % %         count=count+1;
% % % %         temp2(count)=temp(i);
% % % %     end
% % % % end
% % temp3=nanmean(temp);
% % for i=1:length(temp)
% %     if ~isnan(temp(i))==1
% %         temp(i)=temp(i);
% %     else
% %         temp(i)=temp3;
% %     end
% % end
% % x=1:length(temp);
% % a=polyfit(x,temp,1);
% % y=a(1)*x+a(2);
% % hold on
% % plot(x,y,'r');
% % % set(gca,'YTick',1:4:24)
% % % set(gca,'YTickLabel',{'0','4','8','12','16','20'})
% % set(gca,'XTick',30:120:750)
% % set(gca,'XTickLabel',{'1960','1970','1980','1990','2000','2010','2020'})
% % set(gca,'ydir','normal')
% % xlabel('year')
% % title('Haikou')

