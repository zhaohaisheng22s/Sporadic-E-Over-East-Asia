clc;
clear all;
close all
load('Bjdata.mat');
load('Ccdata.mat');
load('Cqdata.mat');
load('Hkdata.mat');
load('Wlmqdata.mat');
load('Lsdata.mat');
load('Lzdata.mat');
load('Ssdata.mat');
load('Xxdata.mat');
load('Mzldata.mat');
load('Szdata.mat');
load('Whdata.mat');
load('Qddata.mat');
load('Gzdata.mat');
load('Kmdata.mat');
load('Wakkdata.mat');
load('Yamadata.mat');
load('Akitdata.mat');
load('Kokudata.mat');
load('Okinadata.mat');

load('cq11.mat');
load('lz10.mat');
load('km11.mat');
load('xa11.mat');
load('ls11.mat');
load('wlmq11.mat');
load('bj11.mat');
bj11=foEs;
load('gz11.mat');
gz11=foEs;
load('hk11.mat');
hk11=foEs;
load('mzl11.mat');
mzl11=foEs;
load('cc11.mat');
cc11=foEs;
load('qd11.mat');
qd11=foEs;
load('xx11.mat');
xx11=foEs;
load('sz11.mat');
sz11=foEs;

% fname =[init 'lasa\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Lsdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Lsdata(i,:)=nan;
    elseif iii<1
        Lsdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Lsdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Lsdata(i,j)<50&Lsdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(ls11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif ls11(count,ii)<50&ls11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,11), imagesc(b)
set(gca,'ydir','normal')
title('Lhasa')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'chongqing\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Cqdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Cqdata(i,:)=nan;
    elseif iii<1
        Cqdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Cqdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Cqdata(i,j)<50&Cqdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(ls11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif cq11(count,ii)<50&cq11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,12), imagesc(b)
set(gca,'ydir','normal')
title('Chongqing')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'sheshan\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Ssdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Ssdata(i,:)=nan;
    elseif iii<1
        Ssdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Ssdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Ssdata(i,j)<50&Ssdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end

    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,14), imagesc(b)
set(gca,'ydir','normal')
title('Sheshan')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'guangzhou\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Gzdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Gzdata(i,:)=nan;
    elseif iii<1
        Gzdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Gzdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Gzdata(i,j)<50&Gzdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(gz11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif gz11(count,ii)<50&gz11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,17), imagesc(b)
set(gca,'ydir','normal')
title('Guangzhou')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'lanzhou\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Lzdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
       Lzdata(i,:)=nan;
    elseif iii<1
        Lzdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Lzdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Lzdata(i,j)<50&Lzdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2010,1,1);
 for count=1:length(lz10)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if lz10(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif lz10(count,ii)<50&lz10(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,6), imagesc(b)
set(gca,'ydir','normal')
title('Lanzhou')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'qingdao\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Qddata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Qddata(i,:)=nan;
    elseif iii<1
        Qddata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Qddata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Qddata(i,j)<50&Qddata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(qd11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif qd11(count,ii)<50&qd11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,8), imagesc(b)
set(gca,'ydir','normal')
title('Qingdao')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'beijing\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Bjdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Bjdata(i,:)=nan;
    elseif iii<1
        Bjdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Bjdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Bjdata(i,j)<50&Bjdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(bj11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if bj11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif bj11(count,ii)<50&bj11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,2), imagesc(b)
set(gca,'ydir','normal')
title('Beijing')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'changchun\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Ccdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Ccdata(i,:)=nan;
    elseif iii<1
        Ccdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Ccdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Ccdata(i,j)<50&Ccdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(cc11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif cc11(count,ii)<50&cc11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,4), imagesc(b)
set(gca,'ydir','normal')
title('Changchun')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'haikou\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Hkdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Hkdata(i,:)=nan;
    elseif iii<1
        Hkdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Hkdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Hkdata(i,j)<50&Hkdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(hk11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif hk11(count,ii)<50&hk11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,18), imagesc(b)
set(gca,'ydir','normal')
title('Haikou')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'wulumuqi\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Wlmqdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Wlmqdata(i,:)=nan;
    elseif iii<1
        Wlmqdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Wlmqdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Wlmqdata(i,j)<50&Wlmqdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(wlmq11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if ls11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif wlmq11(count,ii)<50&wlmq11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,1), imagesc(b)
set(gca,'ydir','normal')
title('Urumchi')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'manzhouli\']; 
% b=readESfo(fname);
count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Mzldata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
        Mzldata(i,:)=nan;
    elseif iii<1
        Mzldata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Mzldata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Mzldata(i,j)<50&Mzldata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(mzl11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if mzl11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif mzl11(count,ii)<50&mzl11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,3), imagesc(b)
set(gca,'ydir','normal')
title('Manzhouli')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'Yamagawa\']; 
% Yamagawa
count1=zeros(24,12);
count2=zeros(24,12);
      datestar=datenum(1965,1,1);
 for count=1:length(Yamadata)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if Yamadata(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif Yamadata(count,ii)<50&Yamadata(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,15), imagesc(b)
set(gca,'ydir','normal')
title('Yamagawa')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

% fname =[init 'wuhan\']; 
% newwuhan
count1=zeros(24,12);
count2=zeros(24,12);
      datestar=datenum(1957,7,1);
 for count=1:length(Whdata)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if Whdata(count,ii)>=5
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif Whdata(count,ii)<5&Whdata(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,13), imagesc(b)
set(gca,'ydir','normal')
title('Wuhan')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})




% fname =[init 'sheshan\']; 
% Okinawa
count1=zeros(24,12);
count2=zeros(24,12);
      datestar=datenum(1972,1,1);
 for count=1:length(Okinadata)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if Okinadata(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif Okinadata(count,ii)<50&Okinadata(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,20), imagesc(b)
set(gca,'ydir','normal')
title('Okinawa')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})



% fname =[init 'Akita\']; 
% Akita
count1=zeros(24,12);
count2=zeros(24,12);
      datestar=datenum(1965,1,1);
 for count=1:length(Akitdata)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if Akitdata(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif Akitdata(count,ii)<50&Akitdata(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,9), imagesc(b)
set(gca,'ydir','normal')
title('Akita')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})


% fname =[init 'changchun\']; 
% wakkanai
count1=zeros(24,12);
count2=zeros(24,12);
      datestar=datenum(1957,1,1);
 for count=1:length(Wakkdata)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if Wakkdata(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif Wakkdata(count,ii)<50&Wakkdata(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,5), imagesc(b)
set(gca,'ydir','normal')
title('Wakkanai')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

count1=zeros(24,12);
count2=zeros(24,12);
      datestar=datenum(1958,1,1);
 for count=1:length(Kokudata)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if Kokudata(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif Kokudata(count,ii)<50&Kokudata(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,10), imagesc(b)
set(gca,'ydir','normal')
title('Koku')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Xxdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
       Xxdata(i,:)=nan;
    elseif iii<1
       Xxdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Xxdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Xxdata(i,j)<50&Xxdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(xx11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if xx11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif xx11(count,ii)<50&xx11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,7), imagesc(b)
set(gca,'ydir','normal')
title('Xinxiang')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Kmdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
       Kmdata(i,:)=nan;
    elseif iii<1
       Kmdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Kmdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Kmdata(i,j)<50&Kmdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(km11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if xx11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif km11(count,ii)<50&km11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,16), imagesc(b)
set(gca,'ydir','normal')
title('Kunming')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})

count1=zeros(24,12);
count2=zeros(24,12);
for i=1:length(Szdata)
    ii=mod(i,420);
    iii=mod(ii,35);
    if iii>30
       Szdata(i,:)=nan;
    elseif iii<1
       Szdata(i,:)=nan;
    end
    iiii=ceil(ii/35);
    if iiii<1
        iiii=12;
    end
    for j=1:24
    if Szdata(i,j)>=50
       count1(j,iiii)=count1(j,iiii)+1;
       count2(j,iiii)=count2(j,iiii)+1;
     elseif Szdata(i,j)<50&Szdata(i,j)~=NaN
        count2(j,iiii)=count2(j,iiii)+1;
    end
    end
end
      datestar=datenum(2011,1,1);
 for count=1:length(sz11)
     iii=datestr(datestar+count-1,5);
     iii=str2num(iii);
     for ii=1:24
         if sz11(count,ii)>=50
            count1(ii,iii)=count1(ii,iii)+1;
            count2(ii,iii)=count2(ii,iii)+1;
          elseif sz11(count,ii)<50&sz11(count,ii)~=9999.00
                 count2(ii,iii)=count2(ii,iii)+1;
          end
        end
 end
    for i=1:24
    for ii=1:12
        b(i,ii)=count1(i,ii)/count2(i,ii);
    end
    end
b(1,1)=1;
subplot(4,5,19), imagesc(b)
set(gca,'ydir','normal')
title('Suzhou')
set(gca,'YTick',1:4:24)
set(gca,'YTickLabel',{'0','4','8','12','16','20'})