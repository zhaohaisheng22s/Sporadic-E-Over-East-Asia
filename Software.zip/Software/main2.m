clc;
clear all;
close all

load('solar.mat');
load('xamm.mat');load('xxmm.mat');load('wlmqmm.mat');load('szmm.mat');load('qdmm.mat');
load('mzlmm.mat');load('lzmm.mat');load('lsmm.mat');load('kmmm.mat');load('hkmm.mat');
load('gzmm.mat');load('bjmm.mat');load('ccmm.mat');load('cqmm.mat');load('okimm.mat');
load('kokmm.mat');load('akimm.mat');load('yammm.mat');load('wakmm.mat');load('ssmm.mat');
load('whmm.mat');
%%%%%%%%%%%%%%%%%%%%%es����ֵ����������ϵ��
%%%%�վ�ֵ
% xarm=nanmean(xamm');xxrm=nanmean(xxmm');wlmqrm=nanmean(wlmqmm');szrm=nanmean(szmm');qdrm=nanmean(qdmm');
% mzlrm=nanmean(mzlmm');lzrm=nanmean(lzmm');lsrm=nanmean(lsmm');kmrm=nanmean(kmmm');hkrm=nanmean(hkmm');
% gzrm=nanmean(gzmm');bjrm=nanmean(bjmm');ccrm=nanmean(ccmm');cqrm=nanmean(cqmm');okirm=nanmean(okimm');
% kokrm=nanmean(kokmm');akirm=nanmean(akimm');yamrm=nanmean(yammm');wakrm=nanmean(wakmm');ssrm=nanmean(ssmm');
% whrm=nanmean(whmm');
% %%%%����
% for i=1:120
% xy(i)=xarm(i)*solar(768-120+i);
% ex2(i)=xarm(i)*xarm(i);
% ey2(i)=solar(768-120+i)*solar(768-120+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(xarm)*nanmean(xarm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-120+1:768))*nanmean(solar(768-120+1:768)));
% dxdy=nanmean(xarm)*nanmean(solar(768-120+1:768));
% rxa=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%��³ľ��
% for i=1:756
% xy(i)=wlmqrm(i)*solar(768-756+i);
% ex2(i)=wlmqrm(i)*wlmqrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(wlmqrm)*nanmean(wlmqrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(wlmqrm)*nanmean(solar(768-756+1:768));
% rwlmq=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:156
% xy(i)=xxrm(i)*solar(768-156+i);
% ex2(i)=xxrm(i)*xxrm(i);
% ey2(i)=solar(768-156+i)*solar(768-156+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(xxrm)*nanmean(xxrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-156+1:768))*nanmean(solar(768-156+1:768)));
% dxdy=nanmean(xxrm)*nanmean(solar(768-156+1:768));
% rxx=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:156
% xy(i)=szrm(i)*solar(768-156+i);
% ex2(i)=szrm(i)*xxrm(i);
% ey2(i)=solar(768-156+i)*solar(768-156+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(xxrm)*nanmean(szrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-156+1:768))*nanmean(solar(768-156+1:768)));
% dxdy=nanmean(szrm)*nanmean(solar(768-156+1:768));
% rsz=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%�ൺ
% for i=1:252
% xy(i)=qdrm(i)*solar(768-252+i);
% ex2(i)=qdrm(i)*qdrm(i);
% ey2(i)=solar(768-252+i)*solar(768-252+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(qdrm)*nanmean(qdrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-252+1:768))*nanmean(solar(768-252+1:768)));
% dxdy=nanmean(qdrm)*nanmean(solar(768-252+1:768));
% rqd=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%������
% for i=1:756
% xy(i)=mzlrm(i)*solar(768-756+i);
% ex2(i)=mzlrm(i)*mzlrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(mzlrm)*nanmean(mzlrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(mzlrm)*nanmean(solar(768-756+1:768));
% rmzl=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:756
% xy(i)=lzrm(i)*solar(768-756+i);
% ex2(i)=lzrm(i)*lzrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(lzrm)*nanmean(lzrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(lzrm)*nanmean(solar(768-756+1:768));
% rlz=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:612
% xy(i)=lsrm(i)*solar(768-612+i);
% ex2(i)=lsrm(i)*lsrm(i);
% ey2(i)=solar(768-612+i)*solar(768-612+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(lsrm)*nanmean(lsrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-612+1:768))*nanmean(solar(768-612+1:768)));
% dxdy=nanmean(lsrm)*nanmean(solar(768-612+1:768));
% rls=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:168
% xy(i)=kmrm(i)*solar(768-168+i);
% ex2(i)=kmrm(i)*kmrm(i);
% ey2(i)=solar(768-168+i)*solar(768-168+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(kmrm)*nanmean(kmrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-168+1:768))*nanmean(solar(768-168+1:768)));
% dxdy=nanmean(kmrm)*nanmean(solar(768-168+1:768));
% rkm=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:756
% xy(i)=hkrm(i)*solar(768-756+i);
% ex2(i)=hkrm(i)*hkrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(hkrm)*nanmean(hkrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(hkrm)*nanmean(solar(768-756+1:768));
% rhk=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:756
% xy(i)=gzrm(i)*solar(768-756+i);
% ex2(i)=gzrm(i)*gzrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(gzrm)*nanmean(gzrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(gzrm)*nanmean(solar(768-756+1:768));
% rgz=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:756
% xy(i)=bjrm(i)*solar(768-756+i);
% ex2(i)=bjrm(i)*bjrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(bjrm)*nanmean(bjrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(bjrm)*nanmean(solar(768-756+1:768));
% rbj=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:756
% xy(i)=cqrm(i)*solar(768-756+i);
% ex2(i)=cqrm(i)*cqrm(i);
% ey2(i)=solar(768-756+i)*solar(768-756+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(cqrm)*nanmean(cqrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
% dxdy=nanmean(cqrm)*nanmean(solar(768-756+1:768));
% rcq=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%����
% for i=1:768
% xy(i)=ccrm(i)*solar(768-768+i);
% ex2(i)=ccrm(i)*ccrm(i);
% ey2(i)=solar(768-768+i)*solar(768-768+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(ccrm)*nanmean(ccrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(768-768+1:768))*nanmean(solar(768-768+1:768)));
% dxdy=nanmean(ccrm)*nanmean(solar(768-768+1:768));
% rcc=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%okirm��1972-2010��
% for i=1:468
% xy(i)=okirm(i)*solar(648-468+i);
% ex2(i)=okirm(i)*okirm(i);
% ey2(i)=solar(648-468+i)*solar(648-468+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(okirm)*nanmean(okirm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(648-468+1:648))*nanmean(solar(648-468+1:648)));
% dxdy=nanmean(okirm)*nanmean(solar(648-468+1:648));
% roki=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%kok��1958-2005��
% for i=1:564
% xy(i)=kokrm(i)*solar(576-564+i);
% ex2(i)=kokrm(i)*kokrm(i);
% ey2(i)=solar(576-564+i)*solar(576-564+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(kokrm)*nanmean(kokrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(576-564+1:576))*nanmean(solar(576-564+1:576)));
% dxdy=nanmean(kokrm)*nanmean(solar(576-564+1:576));
% rkok=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%akirm��1965-1993��
% for i=1:348
% xy(i)=akirm(i)*solar(444-348+i);
% ex2(i)=akirm(i)*akirm(i);
% ey2(i)=solar(444-348+i)*solar(444-348+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(akirm)*nanmean(akirm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(444-348+1:444))*nanmean(solar(444-348+1:444)));
% dxdy=nanmean(akirm)*nanmean(solar(444-348+1:444));
% raki=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%yam��1965-2010��
% for i=1:552
% xy(i)=yamrm(i)*solar(648-552+i);
% ex2(i)=yamrm(i)*yamrm(i);
% ey2(i)=solar(648-552+i)*solar(648-552+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(yamrm)*nanmean(yamrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(648-552+1:648))*nanmean(solar(648-552+1:648)));
% dxdy=nanmean(yamrm)*nanmean(solar(648-552+1:648));
% ryam=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%wakrm��1957-2005��
% for i=1:576
% xy(i)=wakrm(i)*solar(576-576+i);
% ex2(i)=wakrm(i)*wakrm(i);
% ey2(i)=solar(576-576+i)*solar(576-576+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(576-576+1:576))*nanmean(solar(576-576+1:576)));
% dxdy=nanmean(wakrm)*nanmean(solar(576-576+1:576));
% rwak=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%��ɽ
% for i=1:36
% xy(i)=wakrm(i)*solar(108-36+i);
% ex2(i)=wakrm(i)*wakrm(i);
% ey2(i)=solar(108-36+i)*solar(108-36+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(108-36+1:108))*nanmean(solar(108-36+1:108)));
% dxdy=nanmean(wakrm)*nanmean(solar(108-36+1:108));
% rss=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
% %%%%�人��1958-1998��
% for i=1:492
% xy(i)=wakrm(i)*solar(504-492+i);
% ex2(i)=wakrm(i)*wakrm(i);
% ey2(i)=solar(504-492+i)*solar(504-492+i);
% end
% exy=nanmean(xy);
% dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
% dy=sqrt(nanmean(ey2)-nanmean(solar(504-492+1:504))*nanmean(solar(504-492+1:504)));
% dxdy=nanmean(wakrm)*nanmean(solar(504-492+1:504));
% rwh=(exy-dxdy)/(dx*dy)
% xy=[];ex2=[];ey2=[];
%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%es����ֵ����������ϵ��
%%%����
xarm=nanmean(xamm(:,10:17)');xxrm=nanmean(xxmm(:,10:17)');wlmqrm=nanmean(wlmqmm(:,10:17)');szrm=nanmean(szmm(:,10:17)');qdrm=nanmean(qdmm(:,10:17)');
mzlrm=nanmean(mzlmm(:,10:17)');lzrm=nanmean(lzmm(:,10:17)');lsrm=nanmean(lsmm(:,10:17)');kmrm=nanmean(kmmm(:,10:17)');hkrm=nanmean(hkmm(:,10:17)');
gzrm=nanmean(gzmm(:,10:17)');bjrm=nanmean(bjmm(:,10:17)');ccrm=nanmean(ccmm(:,10:17)');cqrm=nanmean(cqmm(:,10:17)');okirm=nanmean(okimm(:,10:17)');
kokrm=nanmean(kokmm(:,10:17)');akirm=nanmean(akimm(:,10:17)');yamrm=nanmean(yammm(:,10:17)');wakrm=nanmean(wakmm(:,10:17)');ssrm=nanmean(ssmm(:,10:17)');
whrm=nanmean(whmm(:,10:17)');
%%%%����
for i=1:120
xy(i)=xarm(i)*solar(768-120+i);
ex2(i)=xarm(i)*xarm(i);
ey2(i)=solar(768-120+i)*solar(768-120+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(xarm)*nanmean(xarm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-120+1:768))*nanmean(solar(768-120+1:768)));
dxdy=nanmean(xarm)*nanmean(solar(768-120+1:768));
rxa=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%��³ľ��
for i=1:756
xy(i)=wlmqrm(i)*solar(768-756+i);
ex2(i)=wlmqrm(i)*wlmqrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wlmqrm)*nanmean(wlmqrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(wlmqrm)*nanmean(solar(768-756+1:768));
rwlmq=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:156
xy(i)=xxrm(i)*solar(768-156+i);
ex2(i)=xxrm(i)*xxrm(i);
ey2(i)=solar(768-156+i)*solar(768-156+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(xxrm)*nanmean(xxrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-156+1:768))*nanmean(solar(768-156+1:768)));
dxdy=nanmean(xxrm)*nanmean(solar(768-156+1:768));
rxx=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:156
xy(i)=szrm(i)*solar(768-156+i);
ex2(i)=szrm(i)*xxrm(i);
ey2(i)=solar(768-156+i)*solar(768-156+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(xxrm)*nanmean(szrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-156+1:768))*nanmean(solar(768-156+1:768)));
dxdy=nanmean(szrm)*nanmean(solar(768-156+1:768));
rsz=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%�ൺ
for i=1:252
xy(i)=qdrm(i)*solar(768-252+i);
ex2(i)=qdrm(i)*qdrm(i);
ey2(i)=solar(768-252+i)*solar(768-252+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(qdrm)*nanmean(qdrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-252+1:768))*nanmean(solar(768-252+1:768)));
dxdy=nanmean(qdrm)*nanmean(solar(768-252+1:768));
rqd=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%������
for i=1:756
xy(i)=mzlrm(i)*solar(768-756+i);
ex2(i)=mzlrm(i)*mzlrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(mzlrm)*nanmean(mzlrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(mzlrm)*nanmean(solar(768-756+1:768));
rmzl=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=lzrm(i)*solar(768-756+i);
ex2(i)=lzrm(i)*lzrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(lzrm)*nanmean(lzrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(lzrm)*nanmean(solar(768-756+1:768));
rlz=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:612
xy(i)=lsrm(i)*solar(768-612+i);
ex2(i)=lsrm(i)*lsrm(i);
ey2(i)=solar(768-612+i)*solar(768-612+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(lsrm)*nanmean(lsrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-612+1:768))*nanmean(solar(768-612+1:768)));
dxdy=nanmean(lsrm)*nanmean(solar(768-612+1:768));
rls=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:168
xy(i)=kmrm(i)*solar(768-168+i);
ex2(i)=kmrm(i)*kmrm(i);
ey2(i)=solar(768-168+i)*solar(768-168+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(kmrm)*nanmean(kmrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-168+1:768))*nanmean(solar(768-168+1:768)));
dxdy=nanmean(kmrm)*nanmean(solar(768-168+1:768));
rkm=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=hkrm(i)*solar(768-756+i);
ex2(i)=hkrm(i)*hkrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(hkrm)*nanmean(hkrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(hkrm)*nanmean(solar(768-756+1:768));
rhk=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=gzrm(i)*solar(768-756+i);
ex2(i)=gzrm(i)*gzrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(gzrm)*nanmean(gzrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(gzrm)*nanmean(solar(768-756+1:768));
rgz=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=bjrm(i)*solar(768-756+i);
ex2(i)=bjrm(i)*bjrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(bjrm)*nanmean(bjrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(bjrm)*nanmean(solar(768-756+1:768));
rbj=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=cqrm(i)*solar(768-756+i);
ex2(i)=cqrm(i)*cqrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(cqrm)*nanmean(cqrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(cqrm)*nanmean(solar(768-756+1:768));
rcq=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:768
xy(i)=ccrm(i)*solar(768-768+i);
ex2(i)=ccrm(i)*ccrm(i);
ey2(i)=solar(768-768+i)*solar(768-768+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(ccrm)*nanmean(ccrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-768+1:768))*nanmean(solar(768-768+1:768)));
dxdy=nanmean(ccrm)*nanmean(solar(768-768+1:768));
rcc=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%okirm��1972-2010��
for i=1:468
xy(i)=okirm(i)*solar(648-468+i);
ex2(i)=okirm(i)*okirm(i);
ey2(i)=solar(648-468+i)*solar(648-468+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(okirm)*nanmean(okirm));
dy=sqrt(nanmean(ey2)-nanmean(solar(648-468+1:648))*nanmean(solar(648-468+1:648)));
dxdy=nanmean(okirm)*nanmean(solar(648-468+1:648));
roki=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%kok��1958-2005��
for i=1:564
xy(i)=kokrm(i)*solar(576-564+i);
ex2(i)=kokrm(i)*kokrm(i);
ey2(i)=solar(576-564+i)*solar(576-564+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(kokrm)*nanmean(kokrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(576-564+1:576))*nanmean(solar(576-564+1:576)));
dxdy=nanmean(kokrm)*nanmean(solar(576-564+1:576));
rkok=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%akirm��1965-1993��
for i=1:348
xy(i)=akirm(i)*solar(444-348+i);
ex2(i)=akirm(i)*akirm(i);
ey2(i)=solar(444-348+i)*solar(444-348+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(akirm)*nanmean(akirm));
dy=sqrt(nanmean(ey2)-nanmean(solar(444-348+1:444))*nanmean(solar(444-348+1:444)));
dxdy=nanmean(akirm)*nanmean(solar(444-348+1:444));
raki=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%yam��1965-2010��
for i=1:552
xy(i)=yamrm(i)*solar(648-552+i);
ex2(i)=yamrm(i)*yamrm(i);
ey2(i)=solar(648-552+i)*solar(648-552+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(yamrm)*nanmean(yamrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(648-552+1:648))*nanmean(solar(648-552+1:648)));
dxdy=nanmean(yamrm)*nanmean(solar(648-552+1:648));
ryam=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%wakrm��1957-2005��
for i=1:576
xy(i)=wakrm(i)*solar(576-576+i);
ex2(i)=wakrm(i)*wakrm(i);
ey2(i)=solar(576-576+i)*solar(576-576+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(576-576+1:576))*nanmean(solar(576-576+1:576)));
dxdy=nanmean(wakrm)*nanmean(solar(576-576+1:576));
rwak=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%��ɽ
for i=1:36
xy(i)=wakrm(i)*solar(108-36+i);
ex2(i)=wakrm(i)*wakrm(i);
ey2(i)=solar(108-36+i)*solar(108-36+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(108-36+1:108))*nanmean(solar(108-36+1:108)));
dxdy=nanmean(wakrm)*nanmean(solar(108-36+1:108));
rss=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%�人��1958-1998��
for i=1:492
xy(i)=wakrm(i)*solar(504-492+i);
ex2(i)=wakrm(i)*wakrm(i);
ey2(i)=solar(504-492+i)*solar(504-492+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(504-492+1:504))*nanmean(solar(504-492+1:504)));
dxdy=nanmean(wakrm)*nanmean(solar(504-492+1:504));
rwh=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%es����ֵ����������ϵ��
%%%%ҹ��
xarm=nanmean(xamm(:,1:4)');xxrm=nanmean(xxmm(:,1:4)');wlmqrm=nanmean(wlmqmm(:,1:4)');szrm=nanmean(szmm(:,1:4)');qdrm=nanmean(qdmm(:,1:4)');
mzlrm=nanmean(mzlmm(:,1:4)');lzrm=nanmean(lzmm(:,1:4)');lsrm=nanmean(lsmm(:,1:4)');kmrm=nanmean(kmmm(:,1:4)');hkrm=nanmean(hkmm(:,1:4)');
gzrm=nanmean(gzmm(:,1:4)');bjrm=nanmean(bjmm(:,1:4)');ccrm=nanmean(ccmm(:,1:4)');cqrm=nanmean(cqmm(:,1:4)');okirm=nanmean(okimm(:,1:4)');
kokrm=nanmean(kokmm(:,1:4)');akirm=nanmean(akimm(:,1:4)');yamrm=nanmean(yammm(:,1:4)');wakrm=nanmean(wakmm(:,1:4)');ssrm=nanmean(ssmm(:,1:4)');
whrm=nanmean(whmm(:,1:4)');
%%%%����
for i=1:120
xy(i)=xarm(i)*solar(768-120+i);
ex2(i)=xarm(i)*xarm(i);
ey2(i)=solar(768-120+i)*solar(768-120+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(xarm)*nanmean(xarm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-120+1:768))*nanmean(solar(768-120+1:768)));
dxdy=nanmean(xarm)*nanmean(solar(768-120+1:768));
rxa=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%��³ľ��
for i=1:756
xy(i)=wlmqrm(i)*solar(768-756+i);
ex2(i)=wlmqrm(i)*wlmqrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wlmqrm)*nanmean(wlmqrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(wlmqrm)*nanmean(solar(768-756+1:768));
rwlmq=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:156
xy(i)=xxrm(i)*solar(768-156+i);
ex2(i)=xxrm(i)*xxrm(i);
ey2(i)=solar(768-156+i)*solar(768-156+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(xxrm)*nanmean(xxrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-156+1:768))*nanmean(solar(768-156+1:768)));
dxdy=nanmean(xxrm)*nanmean(solar(768-156+1:768));
rxx=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:156
xy(i)=szrm(i)*solar(768-156+i);
ex2(i)=szrm(i)*xxrm(i);
ey2(i)=solar(768-156+i)*solar(768-156+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(xxrm)*nanmean(szrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-156+1:768))*nanmean(solar(768-156+1:768)));
dxdy=nanmean(szrm)*nanmean(solar(768-156+1:768));
rsz=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%�ൺ
for i=1:252
xy(i)=qdrm(i)*solar(768-252+i);
ex2(i)=qdrm(i)*qdrm(i);
ey2(i)=solar(768-252+i)*solar(768-252+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(qdrm)*nanmean(qdrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-252+1:768))*nanmean(solar(768-252+1:768)));
dxdy=nanmean(qdrm)*nanmean(solar(768-252+1:768));
rqd=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%������
for i=1:756
xy(i)=mzlrm(i)*solar(768-756+i);
ex2(i)=mzlrm(i)*mzlrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(mzlrm)*nanmean(mzlrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(mzlrm)*nanmean(solar(768-756+1:768));
rmzl=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=lzrm(i)*solar(768-756+i);
ex2(i)=lzrm(i)*lzrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(lzrm)*nanmean(lzrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(lzrm)*nanmean(solar(768-756+1:768));
rlz=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:612
xy(i)=lsrm(i)*solar(768-612+i);
ex2(i)=lsrm(i)*lsrm(i);
ey2(i)=solar(768-612+i)*solar(768-612+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(lsrm)*nanmean(lsrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-612+1:768))*nanmean(solar(768-612+1:768)));
dxdy=nanmean(lsrm)*nanmean(solar(768-612+1:768));
rls=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:168
xy(i)=kmrm(i)*solar(768-168+i);
ex2(i)=kmrm(i)*kmrm(i);
ey2(i)=solar(768-168+i)*solar(768-168+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(kmrm)*nanmean(kmrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-168+1:768))*nanmean(solar(768-168+1:768)));
dxdy=nanmean(kmrm)*nanmean(solar(768-168+1:768));
rkm=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=hkrm(i)*solar(768-756+i);
ex2(i)=hkrm(i)*hkrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(hkrm)*nanmean(hkrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(hkrm)*nanmean(solar(768-756+1:768));
rhk=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=gzrm(i)*solar(768-756+i);
ex2(i)=gzrm(i)*gzrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(gzrm)*nanmean(gzrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(gzrm)*nanmean(solar(768-756+1:768));
rgz=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=bjrm(i)*solar(768-756+i);
ex2(i)=bjrm(i)*bjrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(bjrm)*nanmean(bjrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(bjrm)*nanmean(solar(768-756+1:768));
rbj=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:756
xy(i)=cqrm(i)*solar(768-756+i);
ex2(i)=cqrm(i)*cqrm(i);
ey2(i)=solar(768-756+i)*solar(768-756+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(cqrm)*nanmean(cqrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-756+1:768))*nanmean(solar(768-756+1:768)));
dxdy=nanmean(cqrm)*nanmean(solar(768-756+1:768));
rcq=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%����
for i=1:768
xy(i)=ccrm(i)*solar(768-768+i);
ex2(i)=ccrm(i)*ccrm(i);
ey2(i)=solar(768-768+i)*solar(768-768+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(ccrm)*nanmean(ccrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(768-768+1:768))*nanmean(solar(768-768+1:768)));
dxdy=nanmean(ccrm)*nanmean(solar(768-768+1:768));
rcc=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%okirm��1972-2010��
for i=1:468
xy(i)=okirm(i)*solar(648-468+i);
ex2(i)=okirm(i)*okirm(i);
ey2(i)=solar(648-468+i)*solar(648-468+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(okirm)*nanmean(okirm));
dy=sqrt(nanmean(ey2)-nanmean(solar(648-468+1:648))*nanmean(solar(648-468+1:648)));
dxdy=nanmean(okirm)*nanmean(solar(648-468+1:648));
roki=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%kok��1958-2005��
for i=1:564
xy(i)=kokrm(i)*solar(576-564+i);
ex2(i)=kokrm(i)*kokrm(i);
ey2(i)=solar(576-564+i)*solar(576-564+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(kokrm)*nanmean(kokrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(576-564+1:576))*nanmean(solar(576-564+1:576)));
dxdy=nanmean(kokrm)*nanmean(solar(576-564+1:576));
rkok=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%akirm��1965-1993��
for i=1:348
xy(i)=akirm(i)*solar(444-348+i);
ex2(i)=akirm(i)*akirm(i);
ey2(i)=solar(444-348+i)*solar(444-348+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(akirm)*nanmean(akirm));
dy=sqrt(nanmean(ey2)-nanmean(solar(444-348+1:444))*nanmean(solar(444-348+1:444)));
dxdy=nanmean(akirm)*nanmean(solar(444-348+1:444));
raki=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%yam��1965-2010��
for i=1:552
xy(i)=yamrm(i)*solar(648-552+i);
ex2(i)=yamrm(i)*yamrm(i);
ey2(i)=solar(648-552+i)*solar(648-552+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(yamrm)*nanmean(yamrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(648-552+1:648))*nanmean(solar(648-552+1:648)));
dxdy=nanmean(yamrm)*nanmean(solar(648-552+1:648));
ryam=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%wakrm��1957-2005��
for i=1:576
xy(i)=wakrm(i)*solar(576-576+i);
ex2(i)=wakrm(i)*wakrm(i);
ey2(i)=solar(576-576+i)*solar(576-576+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(576-576+1:576))*nanmean(solar(576-576+1:576)));
dxdy=nanmean(wakrm)*nanmean(solar(576-576+1:576));
rwak=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%��ɽ
for i=1:36
xy(i)=wakrm(i)*solar(108-36+i);
ex2(i)=wakrm(i)*wakrm(i);
ey2(i)=solar(108-36+i)*solar(108-36+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(108-36+1:108))*nanmean(solar(108-36+1:108)));
dxdy=nanmean(wakrm)*nanmean(solar(108-36+1:108));
rss=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%�人��1958-1998��
for i=1:492
xy(i)=wakrm(i)*solar(504-492+i);
ex2(i)=wakrm(i)*wakrm(i);
ey2(i)=solar(504-492+i)*solar(504-492+i);
end
exy=nanmean(xy);
dx=sqrt(nanmean(ex2)-nanmean(wakrm)*nanmean(wakrm));
dy=sqrt(nanmean(ey2)-nanmean(solar(504-492+1:504))*nanmean(solar(504-492+1:504)));
dxdy=nanmean(wakrm)*nanmean(solar(504-492+1:504));
rwh=(exy-dxdy)/(dx*dy)
xy=[];ex2=[];ey2=[];
%%%%%%%%%%%%%%%%%%%%%
%%%%
